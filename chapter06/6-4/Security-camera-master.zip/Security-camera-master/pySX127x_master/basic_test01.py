#from time import localtime, strftime
#my_cur_time = strftime( "%Y_%m_%d_%H_%M_%S", localtime() )
#print( "The time is:" + my_cur_time )
print( "I have no idea what the time is!")
my_variable = "This is my variable"