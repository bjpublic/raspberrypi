def get_email_address():
    #the code to open up a window that gets the email address
    Email = "stupid"
    return Email

def get_email_username():
    #the code to open up a window that gets email username
    Email_Username = "dumb"
    return Email_Username

def send_email():
    # variables from the other def's
    email_address = get_email_address()
    email_username = get_email_username()
    print(email_address)
    
send_email()