class Class:
    # do something
    # example:
    def __init__(self):
        self.var = 2
        print(self.var)

def outsideFunc():
    # operations you want to do
    # example:
    print(a.var * 3)
    
a = Class()
#print(a)

outsideFunc()
Class()